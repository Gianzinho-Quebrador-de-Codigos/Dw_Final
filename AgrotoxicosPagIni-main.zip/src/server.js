const express = require("express");
const res = require("express/lib/response");
const app = express();
const pool = require('./dao/conexao')
/**
 * Caminhos estáticos
 */

app.use('/bscss', express.static('./node_modules/bootstrap/dist/css'));
app.use('/bsjs', express.static('./node_modules/bootstrap/dist/js'));
app.use('/jquery', express.static('./node_modules/jquery/dist'));
app.use('/popperjs', express.static('./node_modules/@popperjs/core/dist/umd'));
app.use('/mask', express.static('./node_modules/jquery-mask-plugin/dist'));
app.use('/publico', express.static(__dirname + '/publico'));
app.use(express.json());
app.use(express.urlencoded({
    extended: true
}))


app.listen(8081,function(){
    console.log('Servidor rodando na porta 8081');
});

app.set('views',__dirname+'/views');



app.get('/sobre',function(req, resp){
    resp.sendFile(__dirname + '/views/sobre.html')
});

app.get('/impacto',function(req, resp){
    resp.sendFile(__dirname + '/views/Impactos.html')
});

app.get('/efeitos_nos',function(req, resp){
    resp.sendFile(__dirname + '/views/efeitos_nos.html')
});

app.get('/efeitos_produ',function(req, resp){
    resp.sendFile(__dirname + '/views/efeitos_produ.html')
});

app.get('/efeitos_inseto',function(req, resp){
    resp.sendFile(__dirname + '/views/efeitos_inseto.html')
});

app.get('/historia',function(req, resp){
    resp.sendFile(__dirname + '/views/historia.html')
});

app.get('/',function(req, resp){
    resp.sendFile(__dirname + '/views/pagina-inicial.html')
});

app.get('/exemplo',function(req, resp){
    resp.sendFile(__dirname + '/views/exemplos.html')
});
